iPhone demo

Upload index.html to a static HTTPS host such as GitHub Pages.
Open the HTTPS page in Safari and tap Start camera.

Camera permission requires a secure context (HTTPS) or localhost.
This demo performs body landmark tracking in the browser; it does not upload
your camera feed to a cloud GPU.
